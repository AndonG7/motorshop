export interface IUserLogin{
  email:string;
  password:string;
}
